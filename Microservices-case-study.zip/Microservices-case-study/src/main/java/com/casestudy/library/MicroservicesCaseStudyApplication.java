package com.casestudy.library;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicesCaseStudyApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicesCaseStudyApplication.class, args);
	}

}
