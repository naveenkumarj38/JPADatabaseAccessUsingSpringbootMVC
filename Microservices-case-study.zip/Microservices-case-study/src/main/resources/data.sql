Insert into book values(1212, 'Ross Sqarez', 0,  'History of Amazon Valley', 2);

Insert into book values(4232, 'H S Parkmay', 5,  'Language Fundamentals', 5);

Insert into book values(2232, 'James Gosling', 2,  'Java Fundamentals', 5);


insert into subscriber values('naveen', 2232, '12-nov-2020', ''); 
insert into subscriber values('Arjun', 4232, '22-Dec-2020', '01-Dec-2020'); 
insert into subscriber values('Dinesh', 111, '01-Jan-2020', '11-Aug-2019'); 